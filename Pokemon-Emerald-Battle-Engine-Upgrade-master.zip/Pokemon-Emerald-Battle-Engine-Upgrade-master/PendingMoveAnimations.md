Gen 4:

Psycho Shift
Trump Card
Heal Block
Me First
Copycat - (Probably doesn't need one, use Mirror Move)
Last Resort
Heart Swap
Magnet Rise (Reserved MRDS)
Magnet Bomb
Stone Edge (Reserved MRDS)
Stealth Rock (Reserved MRDS)
Chatter
Double Hit
Roar of Time
Spacial Rend (Reserved MRDS)
Crush Grip
Magma Storm (Reserved MRDS)
Dark Void
Seed Flare
Shadow Force

_________________________________________________________

Gen 5:

Wide Guard
Guard Split
Power Split
Psyshock
Autotomize
Rage Powder (Reserved MRDS)
Telekinesis
Storm Throw
Sludge Wave (Reserved MRDS)
Heavy Slam
Synchronoise
Soak
Coil (Reserved MRDS)
Low Sweep
Foul Play
Simple Beam
Entrainment
After You
Round
Echoed Voice
Chip Away
Stored Power
Quick Guard
Ally Switch
Shell Smash (Reserved MRDS)
Heal Pulse (Reserved MRDS)
Hex
Sky Drop
Shift Gear (Reserved MRDS)
Circle Throw
Quash
Reflect Type
Retaliate
Final Gambit
Inferno
Water Pledge
Fire Pledge
Grass Pledge
Frost Breath
Dragon Tail
Electroweb (Reserved MRDS)
Dual Chop
Heart Stamp (Reserved MRDS)
Horn Leech (Reserved MRDS)
Sacred Sword (Reserved MRDS)
Heat Crash
Leaf Tornado (Reserved MRDS)
Cotton Guard (Reserved MRDS)
Night Daze
Psystrike
Tail Slap
Head Charge
Gear Grind (Reserved MRDS)
Searing Shot
Techno Blast
Relic Song
Secret Sword (Reserved MRDS)
Glaciate
Bolt Strike
Blue Flare
Fiery Dance (Reserved MRDS)
Freeze Shock
Ice Burn
V-Create
Fusion Flare
Fusion Bolt

_________________________________________________________
  
Gen 6:

Flying Press
Mat Block
Belch
Sticky Web (Reserved MRDS)
Fell Stinger
Phantom Force
Trick or Treat
Noble Roar
Ion Deluge
Forest's Curse
Freeze Dry
Disarming Voice (Reserved MRDS)
Parting Shot
Topsy Turvy
Crafty Shield
Grassy Terrain
Misty Terrain
Electrify
Boomburst (Reserved MRDS)
Fairy Lock
King's Shield
Confide
Diamond Storm (Reserved MRDS)
Steam Eruption
Hyperspace Hole
Water Shuriken (Reserved MRDS)
Spiky Shield
Aromatic Mist
Eerie Impulse
Venom Drench
Powder
Geomancy (Reserved MRDS)
Magnetic Flux
Happy Hour
Electric Terrain
Celebrate
Hold Hands
Hold Back
Infestation
Oblivion Wing
Thousand Arrows
Thousand Waves
Land's Wrath
Light of Ruin
Origin Pulse
Precipice Blades (reserved MRDS)
Dragon Ascent
Hyperspace Fury
